import React from 'react';

const AddNewCustomerComponent =(props)=>{
   
    return(
         <form onSubmit={props.addCustomer}>
          <input type="text" placeholder="customerName" value={props.currentCustName}
          onChange={props.updateName}/>
          <input type="text" placeholder="customerContactNumber" value={props.currentCustContact}
          onChange={props.updateContact}/>
          <input type="text" placeholder="customerAddress" value={props.currentCustAddress}
          onChange={props.updateAddress}/>
           <button> Add Customer </button>
      </form>
    );
}

export default AddNewCustomerComponent;