import React , { Component } from 'react';


class MenuComponent extends Component{

    render(){

        return (
           <h4> Menulist</h4>
        );
    }
}

export default MenuComponent;