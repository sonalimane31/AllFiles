import React,{Component} from 'react';
import AddNewCustomerComponent from './AddNewCustomerComponent';
import axios from 'axios';

class CustomerListComponent extends Component{

    constructor(props){
        super(props);
        this.state = {
            customers:[],
            currentCustName:'',
            currentCustContact:'',
            currentCustAddress:''
        };
    }
    updateName = (newValue) => {
        this.setState({
            currentCustName:newValue.target.value        
        });
    }

    updateContact = (qtyValue) => {
        this.setState({
            currentCustContact:qtyValue.target.value    
        });
    }

    updateAddress = (priceValue) => {
            this.setState({
                currentCustAddress:priceValue.target.value
            });
    }

    getCustomer = () => {
        axios.get(`http://localhost:8003/findallCustomers`)
        .then(res => {
          this.setState({ customers:res.data });
        })

    }
    addCustomer = (event) => {
        event.preventDefault();
        console.log('method Triggered..');
        
        let currentCustName = this.state.currentCustName;
        let currentCustContact = this.state.currentCustContact;
        let currentCustAddress = this.state.currentCustAddress;

        axios.post(`http://localhost:8003/customers`, { 
            customerName: currentCustName,
            customerContactNumber: currentCustContact,
            customerAddress: currentCustAddress
        })
        .then(() => {
            this.getCustomer();
        
        })
        this.setState({
            currentCustName:'',
            currentCustContact:'',
            currentCustAddress:''
        });
      
    }
    render(){

        return(
            <div className="content-title">
                <p>Customer Management</p>
                <table className="productList-table">
                <thead><tr>
                    <th>customerName</th>
                    <th>customerContactNumber</th>
                    <th>customerAddress</th>
                    <th>Action</th>
                    </tr></thead>
                
                </table>
                <div><br/><br/>
            <p>Add New Customer</p>
            <AddNewCustomerComponent
            currentCustName={this.state.currentCustName}
            currentProductPrice={this.state.currentCustContact}
            currentProductQty={this.state.currentCustAddress}
            updateName={this.updateName}
            updateContact={this.updateContact}
            updateAddress={this.updateAddress}
            addCustomer={this.addCustomer}
            />
            </div>
               
            </div>
            
       );
    }   
}

export default CustomerListComponent;