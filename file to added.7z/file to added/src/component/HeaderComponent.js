import React , { Component} from 'react';
import RouterComponent from './RouterComponent';

export default class HeaderComponant extends Component {
  render() {
    return (
      <div >
           <RouterComponent/>
      </div>
    );
  }
}