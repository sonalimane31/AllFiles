import React from 'react';
import {BrowserRouter as Router, Route,NavLink} from 'react-router-dom';
import ProductListComponent from './ProductListComponent';
import AddNewCustomerComponent from './AddNewCustomerComponent';
import CustomerListComponent from './CustomerListComponent';


import '../App.css';

const HomeComponent = () =>(
  // <div className="App-img"> 
  // <img src="./bgimg.jpg" alt="logo" className="img"></img></div>


<div id="myCarousel" class="carousel slide" data-ride="carousel">
  
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
   
  </ol>

 
  <div class="carousel-inner">
    <div class="item active">
      <img src="img1.jpg" alt="Los Angeles" className="img" />
    </div>

    <div class="item">
      <img src="img4.jpg" alt="Chicago" className="img" />
    </div>

    
  </div>

  
  <a class="left carousel-control" href="#myCarousel" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
    <span class="sr-only">Next</span>
  </a>
</div>


)


const OrderComponent = () =>(
  <div>  Order Management </div>
)

const Links = () =>(
 
    <div className="list ">
        <NavLink className="App-link list" exact activeClassName="active" to="/home">&nbsp; Home  &nbsp;</NavLink> 
        <NavLink className="App-link list" activeClassName="active" to="/user">&nbsp; User Management &nbsp;</NavLink>  
        <NavLink className="App-link list" activeClassName="active" to="/product">&nbsp; Product Management &nbsp;</NavLink> 
        <NavLink className="App-link list" activeClassName="active" to="/order">&nbsp; Order Management &nbsp;</NavLink>  
    </div>
)

const RouterComponent = () =>(
    
   <Router>
      <div>
          <section> 
            <Links />
          </section>
             <hr/>
         <section>
                 <div className="App-main">
                      <Route  path="/home" component={HomeComponent}/>
                      <Route  path="/user" component={CustomerListComponent}/>
                      <Route  path="/product" component={ProductListComponent}/>
                      <Route  path="/order" component={OrderComponent}/>
                  </div>
          </section>
            
         </div>    
         
     
   </Router>
     
)

export default RouterComponent;
