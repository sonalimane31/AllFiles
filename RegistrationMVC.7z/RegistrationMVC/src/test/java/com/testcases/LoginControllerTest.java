package com.testcases;


import static org.junit.Assert.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.web.servlet.ModelAndView;

import com.controller.LoginController;
import com.model.Login;
import com.model.User;
import com.service.UserService;

@RunWith(MockitoJUnitRunner.class)
public class LoginControllerTest {

	@InjectMocks
	LoginController loginController;
	
	@Mock
	UserService userService;
	
	@Mock
	HttpServletRequest httpServletRequest;
	
	@Mock
	HttpServletResponse httpServletResponse;
	
	@Test
	public void shouldDisplayLogin() {
		ModelAndView modelAndView = loginController.showLogin();
		assertNotNull(modelAndView);
		assertEquals("LoginPage", modelAndView.getViewName());
	 
	}
	
	@Test
	public void shouldReturnLoginWithUser(){
		Login login = new Login();
		User user = new User();
		when(userService.validateUser(Mockito.anyString(),Mockito.anyString())).thenReturn(user);
		//loginController.LoginUser(httpServletRequest, httpServletResponse, login);
		ModelAndView modelAndView = loginController.LoginUser(httpServletRequest, httpServletResponse, login);
		Assert.assertEquals("Welcome", modelAndView.getViewName());
		verify(userService).validateUser(Mockito.anyString(),Mockito.anyString());
		
	}
	 
	@Test
	public void shouldReturnMessageIfLoginWithIncorrectUser(){
		Login login = new Login();
		User user = new User();
		when(userService.validateUser(Mockito.anyString(),Mockito.anyString())).thenReturn(null);
		
		ModelAndView modelAndView = loginController.LoginUser(httpServletRequest, httpServletResponse, login);
		Assert.assertEquals("LoginPage", modelAndView.getViewName());
		
		verify(userService).validateUser(Mockito.anyString(),Mockito.anyString());
	}
 
}
