package com.testcases;

import javax.persistence.EntityManager;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import org.mockito.runners.MockitoJUnitRunner;

import com.Dao.UserDao;
import com.model.User;

@RunWith(MockitoJUnitRunner.class)
public class UserDaoTest  {

	@InjectMocks
	UserDao userDao;
	
	@Mock
	EntityManager entityManager;
	
	@Test
	public void shouldRegisterUser(){
		
		User user = new User();
		user.setUserId(1);
		user.setFirstname("Sonali");
		user.setLastname("Mane");
		user.setEmail("sonali@gmail.com");
		user.setAddress("Pune");
		user.setUsername("sonali1");
		user.setPassword("sonali1");
		
		when(entityManager.merge(user)).thenReturn(user);
		userDao.register(user);
		verify(entityManager).merge(user);
	}
}
