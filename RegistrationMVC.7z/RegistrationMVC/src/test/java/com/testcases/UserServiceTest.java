package com.testcases;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import com.Dao.UserDao;
import com.model.User;
import com.service.UserService;

@RunWith(MockitoJUnitRunner.class)
public class UserServiceTest {

	
	@InjectMocks
	UserService userService;
	
	@Mock
	UserDao userDao;
	
	
	@Test
	public void shouldCheckForRegisterUser() {
		User user =new User();
		
		user.setUserId(1);
		user.setFirstname("Sonali");
		user.setLastname("Mane");
		user.setEmail("sonali@gmail.com");
		user.setAddress("Pune");
		user.setUsername("sonali1");
		user.setPassword("sonali1");
		
		when(userDao.register(user)).thenReturn(1);
		userService.registerUser(user);
		
	}
	
	@Test
	public void shouldCheckForValidateUser(){
		User user =new User();
		when(userDao.validateUser(Mockito.anyString(),Mockito.anyString())).thenReturn(user);
		userService.validateUser(Mockito.anyString(), Mockito.anyString());
		verify(userDao).validateUser(Mockito.anyString(),Mockito.anyString());
	}

}
