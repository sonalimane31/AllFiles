package com.testcases;

import org.junit.Assert;
import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.web.servlet.ModelAndView;

import com.controller.HelloController;
import com.service.UserService;

@RunWith(MockitoJUnitRunner.class)
public class HelloControllerTest {
	
	@InjectMocks
	HelloController helloController;
	
	@Mock
	UserService userService;
	
	@Test
	public void shouldReturnWelcomeMsg(){
		ModelAndView modelAndView = helloController.helloWorld();
		Assert.assertNotNull(modelAndView);
		assertEquals("hellopage", modelAndView.getViewName());
	}

}
