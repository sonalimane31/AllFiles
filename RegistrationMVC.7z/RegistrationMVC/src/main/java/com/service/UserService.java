package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.Dao.UserDao;
import com.model.User;


@Service(value="userService")
public class UserService {

	@Autowired
	UserDao userDao;
 
	@Transactional
	public Integer registerUser(User user) {
		
		return userDao.register(user);
	}

	public User validateUser(String username, String password) {
		
		return userDao.validateUser( username, password);
	}

	
}
