package com.Dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;

import com.model.User;

@Repository
public class UserDao {

	@PersistenceContext
	EntityManager entityManager;

	public Integer register(User user) {
		// TODO Auto-generated method stub
		entityManager.merge(user);
		return 1;
	}

	public User validateUser(String username, String password) {
		// TODO Auto-generated method stub
		System.out.println("username" +username + "password" +password );
		List<User> users =entityManager.createQuery("from User where firstname = '"+username+"' and password = '"+password+"' " ).getResultList();
		return users.size() > 0 ? users.get(0):null;
	}

}
