package com.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.model.User;
import com.service.UserService;

@Controller
public class RegisterController {
	
	@Autowired
	UserService userService;
	
	@RequestMapping(value="/register",method=RequestMethod.GET)
		public ModelAndView showRegister() {  
    	
		System.out.println("Hii Registered page...");
             
        return new ModelAndView("RegisterPage");  
    }
	
	
	@RequestMapping(value="/registerprocess",method=RequestMethod.POST)
	public ModelAndView RegisterUser(HttpServletRequest request,HttpServletResponse response, @ModelAttribute("registerUser") User user) {  
	
	System.out.println("Hii registerProcess page...");
	
	userService.registerUser(user);
         
    return new ModelAndView("Welcome","firstname",user.getFirstname());  
}

}
