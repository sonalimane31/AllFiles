import React from'react';
import Projectlist from'../containers/Project-list';
import ProjectDetail from '../containers/Project-Detail';
const App=()=>
{
    return(
    <div>
    <h2>Project Names</h2>
    <Projectlist/>
    <hr/>
    <h2>Project Details</h2>
    <ProjectDetail/>
    </div>
    );
}

export default App;