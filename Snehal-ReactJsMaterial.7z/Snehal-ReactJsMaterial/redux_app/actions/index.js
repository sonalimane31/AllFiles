export const selectProject=(project)=>
{
    console.log("Project selected",project.name);
    return{
        type:"PROJECT_SELECTED",
        payload: project
    }
};