import React, { Component } from 'react';
import{connect} from 'react-redux';

class ProjectDetail extends Component{
    render()
    {
        if(!this.props.project){
            return(<h3> Select Project.......</h3>);
        }
    return(
        <div>
        <h2>{this.props.project.id}</h2>
        <h2>{this.props.project.name}</h2>
        <h2>{this.props.project.team}</h2>
        </div>
        );
    }
}

function mapStateToProps(state){
    return{
        project:state.activeProject
    };
}

 export default connect(mapStateToProps)(ProjectDetail);