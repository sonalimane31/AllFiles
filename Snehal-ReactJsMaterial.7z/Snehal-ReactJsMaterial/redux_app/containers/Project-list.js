import React, { Component } from 'react';
import{bindActionCreators} from 'redux';
import{connect} from 'react-redux';
import {selectProject} from '../actions/index';

class Projectlist extends Component
{
    createListItems()
    {
    return this.props.projects.map((project)=>
{
    return(
        <li 
        key={project.id} 
        onClick={()=> this.props.selectProject(project)}>
        {project.name} {project.team}</li>
    );
});
    }
    
    render()
    {
        return(
            <ul>
            
            {this.createListItems()}
            </ul>
        );
        
    }
}
function mapStateToProps(state){
    return{
        projects:state.projects
    };
}

function matchDispatchToProps(dispatch){
    return bindActionCreators({selectProject: selectProject},dispatch)
}

export default connect(mapStateToProps,matchDispatchToProps)(Projectlist);
