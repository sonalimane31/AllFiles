import {combineReducers} from 'redux';
import projectreducer from'./reducer-projects';
import ActiveProjectReducer from'./reducer-active-project';

const allReducers=combineReducers({
    projects:projectreducer,
    activeProject:ActiveProjectReducer
});
export default allReducers;