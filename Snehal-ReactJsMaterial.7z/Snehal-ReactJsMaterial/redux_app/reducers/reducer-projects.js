export default function()
{
    return[
        {
            id:1,
            name:"SLB",
            lead:"John",
            team:12
        },
        {
            id:2,
            name:"TCI",
            lead:"allen",
            team:5
        },
        {
            id:3,
            name:"JD",
            lead:"Albert",
            team:7
        }
    ]
    
}